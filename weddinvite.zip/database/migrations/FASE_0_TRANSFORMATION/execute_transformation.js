#!/usr/bin/env node

// Alias file untuk execute_transformation.cjs
// Digunakan untuk kompatibilitas dengan test yang mengharapkan .js extension

require('./execute_transformation.cjs');
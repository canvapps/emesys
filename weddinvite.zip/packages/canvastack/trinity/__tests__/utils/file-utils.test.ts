/**
 * @fileoverview Tests for File Utils
 */

import { FileUtils } from '../../src/utils/file-utils';

// Basic test for file utils
const fileUtils = new FileUtils();

console.log('FileUtils tests completed');

export default true;
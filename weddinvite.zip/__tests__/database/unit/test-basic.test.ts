import { test, expect } from 'vitest';

test('basic test should pass', () => {
  expect(1 + 1).toBe(2);
});
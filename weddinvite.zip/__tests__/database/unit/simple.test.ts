import { describe, it, expect } from 'vitest';

describe('Simple Test', () => {
  it('should run basic test', () => {
    expect(1 + 1).toBe(2);
  });
});
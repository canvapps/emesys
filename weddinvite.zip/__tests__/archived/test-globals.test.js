test('globals test', () => {
  expect(1 + 1).toBe(2);
});
import { test, expect } from 'vitest';

test('basic test', () => {
  expect(1 + 1).toBe(2);
});
import { test, expect } from 'vitest';

test('basic javascript test', () => {
  expect(1 + 1).toBe(2);
});
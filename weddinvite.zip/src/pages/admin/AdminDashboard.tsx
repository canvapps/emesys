
import Dashboard from '@/pages/admin/Dashboard';

const AdminDashboard = () => {
  return <Dashboard />;
};

export default AdminDashboard;
